@echo off

rem Modified Batch menu - original was created by B. Bellina, 2/2012
rem This menu has been added to this compilation so it can be played on The Internet Archive
:top
rem dir
:menu
echo.
echo Choose which game you would like to play from this compilation:
echo. 
echo 1 =  Chinese Chess (CCHESS)
echo 2 =  Chinese Chess (XQ)
echo. 
echo Other options:
echo 3 = Exit to DOS
echo.
rem All allowed options must be listed in the line below
choice /n /c:1234 Make a selection:
echo.
rem The errorlevel lines must be in reverse order
if errorlevel ==3 goto three
if errorlevel ==2 goto two
if errorlevel ==1 goto one
goto end

:one
echo Launching game
cchess.exe

:two
echo Launching game
xq.exe

:three
cls
goto end

:end

